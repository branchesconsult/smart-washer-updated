<?php

return [

    'view' => 'backend.includes.partials.breadcrumbs',

];
